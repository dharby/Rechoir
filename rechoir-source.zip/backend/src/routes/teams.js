const express = require('express');
const router = express.Router();
const { 
  getTeams, 
  createTeam, 
  getTeam, 
  updateTeam, 
  deleteTeam,
  getTeamStats,
  getPlatformStats
} = require('../controllers/teamController');
const { authenticateSuperAdmin } = require('../middleware/auth');

router.use(authenticateSuperAdmin);

router.get('/', getTeams);
router.post('/', createTeam);
router.get('/stats', getPlatformStats);
router.get('/:id', getTeam);
router.patch('/:id', updateTeam);
router.delete('/:id', deleteTeam);
router.get('/:id/stats', getTeamStats);

module.exports = router;
