const express = require('express');
const router = express.Router();
const { 
  getPayments, 
  createPayment, 
  getPayment, 
  updatePayment, 
  deletePayment,
  updatePaymentRecord,
  addPaymentRecords
} = require('../controllers/paymentController');
const { authenticateTeamLead } = require('../middleware/auth');

router.use(authenticateTeamLead);

router.get('/', getPayments);
router.post('/', createPayment);
router.get('/:id', getPayment);
router.patch('/:id', updatePayment);
router.delete('/:id', deletePayment);
router.patch('/:id/records/:recordId', updatePaymentRecord);
router.post('/:id/records', addPaymentRecords);

module.exports = router;
