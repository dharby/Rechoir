const express = require('express');
const router = express.Router();
const { 
  getUniformEvents, 
  createUniformEvent, 
  getUniformEvent, 
  updateUniformEvent, 
  deleteUniformEvent,
  toggleUniformReadiness,
  addUniformReadinessMembers
} = require('../controllers/uniformController');
const { authenticateTeamLead } = require('../middleware/auth');

router.use(authenticateTeamLead);

router.get('/', getUniformEvents);
router.post('/', createUniformEvent);
router.get('/:id', getUniformEvent);
router.patch('/:id', updateUniformEvent);
router.delete('/:id', deleteUniformEvent);
router.patch('/:id/readiness/:readinessId', toggleUniformReadiness);
router.post('/:id/readiness', addUniformReadinessMembers);

module.exports = router;
