const express = require('express');
const router = express.Router();
const multer = require('multer');
const { 
  getTeamMembers, 
  addMember, 
  bulkImportMembers,
  previewBulkImport,
  getMember, 
  updateMember, 
  toggleMemberAccess,
  removeMember,
  regenerateAccessCode
} = require('../controllers/memberController');
const { authenticateTeamLead } = require('../middleware/auth');

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel',
      'text/csv'
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only .xlsx, .xls, and .csv files are allowed.'));
    }
  }
});

router.use(authenticateTeamLead);

router.get('/', getTeamMembers);
router.post('/', addMember);
router.post('/bulk', upload.single('file'), bulkImportMembers);
router.post('/bulk/preview', upload.single('file'), previewBulkImport);
router.get('/:id', getMember);
router.patch('/:id', updateMember);
router.patch('/:id/toggle-access', toggleMemberAccess);
router.patch('/:id/regenerate-code', regenerateAccessCode);
router.delete('/:id', removeMember);

module.exports = router;
