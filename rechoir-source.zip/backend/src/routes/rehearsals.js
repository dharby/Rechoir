const express = require('express');
const router = express.Router();
const { 
  getRehearsals, 
  createRehearsal, 
  getRehearsal, 
  updateRehearsal, 
  deleteRehearsal,
  markAttendance,
  getAttendanceReport
} = require('../controllers/rehearsalController');
const { authenticateTeamLead } = require('../middleware/auth');

router.use(authenticateTeamLead);

router.get('/', getRehearsals);
router.post('/', createRehearsal);
router.get('/:id', getRehearsal);
router.patch('/:id', updateRehearsal);
router.delete('/:id', deleteRehearsal);
router.patch('/:id/attendance/:memberId', markAttendance);
router.get('/attendance/:memberId', getAttendanceReport);

module.exports = router;
