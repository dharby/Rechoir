const express = require('express');
const router = express.Router();
const { 
  getChatRooms, 
  createChatRoom, 
  getChatMessages, 
  sendMessage, 
  deleteMessage,
  markMessagesRead
} = require('../controllers/chatController');
const { authenticateTeamLead, authenticateMember, authenticateAny } = require('../middleware/auth');

router.use(authenticateAny);

router.get('/rooms', getChatRooms);
router.post('/rooms', authenticateTeamLead, createChatRoom);
router.get('/rooms/:id/messages', getChatMessages);
router.post('/rooms/:id/messages', sendMessage);
router.patch('/rooms/:id/read', markMessagesRead);
router.delete('/rooms/:id/messages/:messageId', deleteMessage);

module.exports = router;
