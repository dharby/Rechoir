const express = require('express');
const router = express.Router();
const { 
  getPrayerChains, 
  createPrayerChain, 
  getPrayerChain, 
  updatePrayerChain, 
  deletePrayerChain,
  addChainAssignment,
  updateChainAssignment,
  completePrayerChain
} = require('../controllers/prayerChainController');
const { authenticateTeamLead } = require('../middleware/auth');

router.use(authenticateTeamLead);

router.get('/', getPrayerChains);
router.post('/', createPrayerChain);
router.get('/:id', getPrayerChain);
router.patch('/:id', updatePrayerChain);
router.delete('/:id', deletePrayerChain);
router.post('/:id/assignments', addChainAssignment);
router.patch('/:id/assignments/:assignmentId', updateChainAssignment);
router.post('/:id/complete', completePrayerChain);

module.exports = router;
