const express = require('express');
const router = express.Router();
const { 
  superAdminRegister, 
  superAdminLogin,
  teamLeadRegister,
  teamLeadLogin,
  memberLogin,
  memberLoginWithPassword,
  setMemberPassword,
  refreshToken
} = require('../controllers/authController');
const { authenticateSuperAdmin, authenticateTeamLead, authenticateMember, authenticateAny } = require('../middleware/auth');
const rateLimit = require('express-rate-limit');
const config = require('../config');

const authLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  message: { error: 'Too many attempts. Please try again in 15 minutes.' }
});

router.post('/super-admin/register', authLimiter, superAdminRegister);
router.post('/super-admin/login', authLimiter, superAdminLogin);

router.post('/team-lead/register', authenticateSuperAdmin, teamLeadRegister);
router.post('/team-lead/login', authLimiter, teamLeadLogin);

router.post('/member/login', authLimiter, memberLogin);
router.post('/member/login-password', authLimiter, memberLoginWithPassword);
router.post('/member/set-password', authenticateMember, setMemberPassword);

router.post('/refresh', refreshToken);

module.exports = router;
