const express = require('express');
const router = express.Router();
const { 
  getNotifications, 
  markNotificationRead, 
  markAllNotificationsRead,
  getUnreadCount
} = require('../controllers/notificationController');
const { authenticateTeamLead, authenticateMember } = require('../middleware/auth');

router.use(authenticateTeamLead, authenticateMember);

router.get('/', getNotifications);
router.get('/unread-count', getUnreadCount);
router.patch('/read-all', markAllNotificationsRead);
router.patch('/:id/read', markNotificationRead);

module.exports = router;
