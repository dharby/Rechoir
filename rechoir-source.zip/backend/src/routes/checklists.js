const express = require('express');
const router = express.Router();
const { 
  getChecklists, 
  createChecklist, 
  getChecklist, 
  updateChecklist, 
  deleteChecklist,
  addChecklistItem,
  toggleChecklistItem,
  deleteChecklistItem,
  getMemberChecklists
} = require('../controllers/checklistController');
const { authenticateTeamLead } = require('../middleware/auth');

router.use(authenticateTeamLead);

router.get('/', getChecklists);
router.post('/', createChecklist);
router.get('/:id', getChecklist);
router.patch('/:id', updateChecklist);
router.delete('/:id', deleteChecklist);
router.post('/:id/items', addChecklistItem);
router.patch('/:id/items/:itemId', toggleChecklistItem);
router.delete('/:id/items/:itemId', deleteChecklistItem);
router.get('/member/:memberId', getMemberChecklists);

module.exports = router;
