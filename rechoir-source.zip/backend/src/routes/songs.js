const express = require('express');
const router = express.Router();
const { 
  getSongs, 
  createSong, 
  getSong, 
  updateSong, 
  deleteSong,
  assignSong,
  updateSongAssignment,
  updateSongAssignmentByMember,
  removeSongAssignment,
  getWeeklySongReadiness
} = require('../controllers/songController');
const { authenticateTeamLead, authenticateMember } = require('../middleware/auth');

router.use(authenticateTeamLead);

router.get('/', getSongs);
router.get('/weekly-readiness', getWeeklySongReadiness);
router.post('/', createSong);
router.get('/:id', getSong);
router.patch('/:id', updateSong);
router.delete('/:id', deleteSong);
router.post('/:id/assign', assignSong);
router.patch('/:id/assignments/:assignmentId', updateSongAssignment);
router.delete('/:id/assignments/:assignmentId', removeSongAssignment);

router.patch('/:id/my-readiness', authenticateMember, updateSongAssignmentByMember);

module.exports = router;
