const { z } = require('zod');

const passwordSchema = z.string()
  .min(8, 'Password must be at least 8 characters')
  .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
  .regex(/[0-9]/, 'Password must contain at least one number')
  .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character');

const emailSchema = z.string().email('Invalid email address');

const phoneSchema = z.string().optional();

const superAdminRegisterSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  name: z.string().min(2, 'Name must be at least 2 characters')
});

const superAdminLoginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Password is required')
});

const teamLeadRegisterSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  name: z.string().min(2, 'Name must be at least 2 characters'),
  phone: phoneSchema,
  teamName: z.string().min(2, 'Team name must be at least 2 characters')
});

const teamLeadLoginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Password is required')
});

const memberLoginSchema = z.object({
  email: emailSchema,
  accessCode: z.string().length(6, 'Access code must be 6 digits')
});

const setMemberPasswordSchema = z.object({
  accessCode: z.string().length(6),
  password: passwordSchema
});

const memberSchema = z.object({
  email: emailSchema,
  name: z.string().min(2, 'Name must be at least 2 characters'),
  phone: phoneSchema,
  specialization: z.enum(['SINGER', 'INSTRUMENTALIST', 'TEAM_LEAD', 'OFFICER']).optional()
});

const bulkMemberSchema = z.object({
  members: z.array(memberSchema).min(1, 'At least one member is required')
});

const prayerChainSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  description: z.string().optional(),
  type: z.enum(['CONTINUOUS', 'SCHEDULED']),
  startDate: z.string().datetime(),
  endDate: z.string().datetime().optional(),
  memberIds: z.array(z.string().uuid()).optional()
});

const prayerChainAssignmentSchema = z.object({
  memberId: z.string().uuid(),
  scheduledTime: z.string().datetime().optional()
});

const duePaymentSchema = z.object({
  title: z.string().min(2, 'Title must be at least 2 characters'),
  amount: z.number().positive('Amount must be positive'),
  dueDate: z.string().datetime(),
  memberIds: z.array(z.string().uuid()).optional()
});

const rehearsalSchema = z.object({
  title: z.string().min(2, 'Title must be at least 2 characters'),
  date: z.string().datetime(),
  startTime: z.string().min(4, 'Start time is required'),
  endTime: z.string().min(4, 'End time is required'),
  location: z.string().optional(),
  agenda: z.string().optional()
});

const attendanceSchema = z.object({
  memberId: z.string().uuid(),
  status: z.enum(['PRESENT', 'ABSENT', 'EXCUSED']),
  arrivalTime: z.string().datetime().optional()
});

const weeklyChecklistSchema = z.object({
  title: z.string().min(2, 'Title must be at least 2 characters'),
  weekStartDate: z.string().datetime(),
  items: z.array(z.object({
    memberId: z.string().uuid(),
    description: z.string().min(2, 'Description is required')
  })).optional()
});

const checklistItemSchema = z.object({
  isCompleted: z.boolean()
});

const uniformEventSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  date: z.string().datetime(),
  description: z.string().optional(),
  imageUrl: z.string().url().optional().nullable(),
  memberIds: z.array(z.string().uuid()).optional()
});

const songSchema = z.object({
  title: z.string().min(2, 'Title must be at least 2 characters'),
  key: z.string().optional(),
  youtubeUrl: z.string().url().optional().nullable(),
  practiceNotes: z.string().optional(),
  targetReadinessDate: z.string().datetime(),
  memberIds: z.array(z.string().uuid()).optional()
});

const songAssignmentSchema = z.object({
  status: z.enum(['NOT_STARTED', 'LEARNING', 'READY', 'PERFECT']),
  note: z.string().optional()
});

const chatMessageSchema = z.object({
  content: z.string().min(1, 'Message content is required'),
  type: z.enum(['TEXT', 'FILE', 'VOICE']).optional()
});

module.exports = {
  passwordSchema,
  emailSchema,
  superAdminRegisterSchema,
  superAdminLoginSchema,
  teamLeadRegisterSchema,
  teamLeadLoginSchema,
  memberLoginSchema,
  setMemberPasswordSchema,
  memberSchema,
  bulkMemberSchema,
  prayerChainSchema,
  prayerChainAssignmentSchema,
  duePaymentSchema,
  rehearsalSchema,
  attendanceSchema,
  weeklyChecklistSchema,
  checklistItemSchema,
  uniformEventSchema,
  songSchema,
  songAssignmentSchema,
  chatMessageSchema
};
