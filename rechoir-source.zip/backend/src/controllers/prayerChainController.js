const prisma = require('../config/database');
const { prayerChainSchema, prayerChainAssignmentSchema } = require('../utils/validation');

const getPrayerChains = async (req, res, next) => {
  try {
    const chains = await prisma.prayerChain.findMany({
      where: { teamId: req.user.teamId },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        },
        _count: { select: { assignments: true } }
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json(chains);
  } catch (error) {
    next(error);
  }
};

const createPrayerChain = async (req, res, next) => {
  try {
    const data = prayerChainSchema.parse(req.body);

    const chain = await prisma.prayerChain.create({
      data: {
        name: data.name,
        description: data.description,
        type: data.type,
        startDate: new Date(data.startDate),
        endDate: data.endDate ? new Date(data.endDate) : null,
        teamId: req.user.teamId,
        assignments: data.memberIds ? {
          create: data.memberIds.map(memberId => ({
            memberId,
            status: 'ACTIVE'
          }))
        } : undefined
      },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.status(201).json({
      message: 'Prayer chain created successfully',
      chain
    });
  } catch (error) {
    next(error);
  }
};

const getPrayerChain = async (req, res, next) => {
  try {
    const chain = await prisma.prayerChain.findUnique({
      where: { id: req.params.id },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        }
      }
    });

    if (!chain) {
      return res.status(404).json({ error: 'Prayer chain not found' });
    }

    if (chain.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(chain);
  } catch (error) {
    next(error);
  }
};

const updatePrayerChain = async (req, res, next) => {
  try {
    const { name, description, type, startDate, endDate } = req.body;

    const chain = await prisma.prayerChain.findUnique({
      where: { id: req.params.id }
    });

    if (!chain) {
      return res.status(404).json({ error: 'Prayer chain not found' });
    }

    if (chain.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.prayerChain.update({
      where: { id: req.params.id },
      data: {
        name: name || chain.name,
        description: description !== undefined ? description : chain.description,
        type: type || chain.type,
        startDate: startDate ? new Date(startDate) : chain.startDate,
        endDate: endDate !== undefined ? (endDate ? new Date(endDate) : null) : chain.endDate
      },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.json({
      message: 'Prayer chain updated successfully',
      chain: updated
    });
  } catch (error) {
    next(error);
  }
};

const deletePrayerChain = async (req, res, next) => {
  try {
    const chain = await prisma.prayerChain.findUnique({
      where: { id: req.params.id }
    });

    if (!chain) {
      return res.status(404).json({ error: 'Prayer chain not found' });
    }

    if (chain.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.prayerChain.delete({
      where: { id: req.params.id }
    });

    res.json({ message: 'Prayer chain deleted successfully' });
  } catch (error) {
    next(error);
  }
};

const addChainAssignment = async (req, res, next) => {
  try {
    const data = prayerChainAssignmentSchema.parse(req.body);

    const chain = await prisma.prayerChain.findUnique({
      where: { id: req.params.id }
    });

    if (!chain) {
      return res.status(404).json({ error: 'Prayer chain not found' });
    }

    if (chain.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const member = await prisma.member.findUnique({
      where: { id: data.memberId }
    });

    if (!member || member.teamId !== req.user.teamId) {
      return res.status(404).json({ error: 'Member not found in your team' });
    }

    const assignment = await prisma.prayerChainAssignment.create({
      data: {
        chainId: chain.id,
        memberId: data.memberId,
        scheduledTime: data.scheduledTime ? new Date(data.scheduledTime) : null,
        status: 'ACTIVE'
      },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.status(201).json({
      message: 'Assignment added successfully',
      assignment
    });
  } catch (error) {
    if (error.code === 'P2002') {
      return res.status(409).json({ error: 'Member already assigned to this chain' });
    }
    next(error);
  }
};

const updateChainAssignment = async (req, res, next) => {
  try {
    const { scheduledTime, status } = req.body;

    const assignment = await prisma.prayerChainAssignment.findUnique({
      where: { id: req.params.assignmentId },
      include: { chain: true }
    });

    if (!assignment) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    if (assignment.chain.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.prayerChainAssignment.update({
      where: { id: req.params.assignmentId },
      data: {
        scheduledTime: scheduledTime ? new Date(scheduledTime) : assignment.scheduledTime,
        status: status || assignment.status
      },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.json({
      message: 'Assignment updated successfully',
      assignment: updated
    });
  } catch (error) {
    next(error);
  }
};

const completePrayerChain = async (req, res, next) => {
  try {
    const chain = await prisma.prayerChain.findUnique({
      where: { id: req.params.id }
    });

    if (!chain) {
      return res.status(404).json({ error: 'Prayer chain not found' });
    }

    if (chain.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.prayerChainAssignment.updateMany({
      where: { chainId: chain.id },
      data: { status: 'COMPLETED' }
    });

    const updated = await prisma.prayerChain.update({
      where: { id: req.params.id },
      data: { endDate: new Date() },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.json({
      message: 'Prayer chain marked as answered',
      chain: updated
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getPrayerChains,
  createPrayerChain,
  getPrayerChain,
  updatePrayerChain,
  deletePrayerChain,
  addChainAssignment,
  updateChainAssignment,
  completePrayerChain
};
