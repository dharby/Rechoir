const prisma = require('../config/database');
const { uniformEventSchema } = require('../utils/validation');

const getUniformEvents = async (req, res, next) => {
  try {
    const events = await prisma.uniformEvent.findMany({
      where: { teamId: req.user.teamId },
      include: {
        readiness: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        },
        _count: { select: { readiness: true } }
      },
      orderBy: { date: 'asc' }
    });

    const eventsWithStatus = events.map(event => {
      const total = event.readiness.length;
      const ready = event.readiness.filter(r => r.isReady).length;
      return {
        ...event,
        stats: { ready, total, percentage: total > 0 ? Math.round((ready / total) * 100) : 0 }
      };
    });

    res.json(eventsWithStatus);
  } catch (error) {
    next(error);
  }
};

const createUniformEvent = async (req, res, next) => {
  try {
    const data = uniformEventSchema.parse(req.body);

    const event = await prisma.uniformEvent.create({
      data: {
        name: data.name,
        date: new Date(data.date),
        description: data.description,
        imageUrl: data.imageUrl,
        teamId: req.user.teamId,
        readiness: data.memberIds ? {
          create: data.memberIds.map(memberId => ({
            memberId,
            isReady: false
          }))
        } : undefined
      },
      include: {
        readiness: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.status(201).json({
      message: 'Uniform event created successfully',
      event
    });
  } catch (error) {
    next(error);
  }
};

const getUniformEvent = async (req, res, next) => {
  try {
    const event = await prisma.uniformEvent.findUnique({
      where: { id: req.params.id },
      include: {
        readiness: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        }
      }
    });

    if (!event) {
      return res.status(404).json({ error: 'Uniform event not found' });
    }

    if (event.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(event);
  } catch (error) {
    next(error);
  }
};

const updateUniformEvent = async (req, res, next) => {
  try {
    const { name, date, description, imageUrl } = req.body;

    const event = await prisma.uniformEvent.findUnique({
      where: { id: req.params.id }
    });

    if (!event) {
      return res.status(404).json({ error: 'Uniform event not found' });
    }

    if (event.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.uniformEvent.update({
      where: { id: req.params.id },
      data: {
        name: name || event.name,
        date: date ? new Date(date) : event.date,
        description: description !== undefined ? description : event.description,
        imageUrl: imageUrl !== undefined ? imageUrl : event.imageUrl
      },
      include: {
        readiness: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.json({
      message: 'Uniform event updated successfully',
      event: updated
    });
  } catch (error) {
    next(error);
  }
};

const deleteUniformEvent = async (req, res, next) => {
  try {
    const event = await prisma.uniformEvent.findUnique({
      where: { id: req.params.id }
    });

    if (!event) {
      return res.status(404).json({ error: 'Uniform event not found' });
    }

    if (event.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.uniformEvent.delete({
      where: { id: req.params.id }
    });

    res.json({ message: 'Uniform event deleted successfully' });
  } catch (error) {
    next(error);
  }
};

const toggleUniformReadiness = async (req, res, next) => {
  try {
    const readiness = await prisma.uniformReadiness.findUnique({
      where: { id: req.params.readinessId },
      include: { event: true }
    });

    if (!readiness) {
      return res.status(404).json({ error: 'Readiness record not found' });
    }

    if (readiness.event.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.uniformReadiness.update({
      where: { id: req.params.readinessId },
      data: { isReady: !readiness.isReady },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.json({
      message: `Uniform readiness marked as ${updated.isReady ? 'ready' : 'not ready'}`,
      readiness: updated
    });
  } catch (error) {
    next(error);
  }
};

const addUniformReadinessMembers = async (req, res, next) => {
  try {
    const { memberIds } = req.body;

    const event = await prisma.uniformEvent.findUnique({
      where: { id: req.params.id }
    });

    if (!event) {
      return res.status(404).json({ error: 'Uniform event not found' });
    }

    if (event.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const existingRecords = await prisma.uniformReadiness.findMany({
      where: { eventId: event.id },
      select: { memberId: true }
    });

    const existingMemberIds = new Set(existingRecords.map(r => r.memberId));
    const newMemberIds = memberIds.filter(id => !existingMemberIds.has(id));

    const created = await prisma.uniformReadiness.createMany({
      data: newMemberIds.map(memberId => ({
        eventId: event.id,
        memberId,
        isReady: false
      }))
    });

    res.status(201).json({
      message: `Added ${created.count} members to uniform event`,
      count: created.count
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getUniformEvents,
  createUniformEvent,
  getUniformEvent,
  updateUniformEvent,
  deleteUniformEvent,
  toggleUniformReadiness,
  addUniformReadinessMembers
};
