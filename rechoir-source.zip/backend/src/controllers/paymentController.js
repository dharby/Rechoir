const prisma = require('../config/database');
const { duePaymentSchema } = require('../utils/validation');

const getPayments = async (req, res, next) => {
  try {
    const payments = await prisma.duePayment.findMany({
      where: { teamId: req.user.teamId },
      include: {
        records: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        },
        _count: { select: { records: true } }
      },
      orderBy: { dueDate: 'asc' }
    });

    const paymentsWithStatus = payments.map(payment => {
      const total = payment.records.length;
      const paid = payment.records.filter(r => r.isPaid).length;
      let status = 'PENDING';
      if (paid === total && total > 0) status = 'COMPLETED';
      else if (paid > 0) status = 'PARTIAL';
      else if (new Date(payment.dueDate) < new Date()) status = 'OVERDUE';

      return { ...payment, paymentStatus: status, paidCount: paid, totalCount: total };
    });

    res.json(paymentsWithStatus);
  } catch (error) {
    next(error);
  }
};

const createPayment = async (req, res, next) => {
  try {
    const data = duePaymentSchema.parse(req.body);

    const payment = await prisma.duePayment.create({
      data: {
        title: data.title,
        amount: data.amount,
        dueDate: new Date(data.dueDate),
        teamId: req.user.teamId,
        records: data.memberIds ? {
          create: data.memberIds.map(memberId => ({
            memberId,
            isPaid: false
          }))
        } : undefined
      },
      include: {
        records: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.status(201).json({
      message: 'Payment created successfully',
      payment
    });
  } catch (error) {
    next(error);
  }
};

const getPayment = async (req, res, next) => {
  try {
    const payment = await prisma.duePayment.findUnique({
      where: { id: req.params.id },
      include: {
        records: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        }
      }
    });

    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    if (payment.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const total = payment.records.length;
    const paid = payment.records.filter(r => r.isPaid).length;
    let status = 'PENDING';
    if (paid === total && total > 0) status = 'COMPLETED';
    else if (paid > 0) status = 'PARTIAL';
    else if (new Date(payment.dueDate) < new Date()) status = 'OVERDUE';

    res.json({ ...payment, paymentStatus: status, paidCount: paid, totalCount: total });
  } catch (error) {
    next(error);
  }
};

const updatePayment = async (req, res, next) => {
  try {
    const { title, amount, dueDate } = req.body;

    const payment = await prisma.duePayment.findUnique({
      where: { id: req.params.id }
    });

    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    if (payment.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.duePayment.update({
      where: { id: req.params.id },
      data: {
        title: title || payment.title,
        amount: amount !== undefined ? amount : payment.amount,
        dueDate: dueDate ? new Date(dueDate) : payment.dueDate
      },
      include: {
        records: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.json({
      message: 'Payment updated successfully',
      payment: updated
    });
  } catch (error) {
    next(error);
  }
};

const deletePayment = async (req, res, next) => {
  try {
    const payment = await prisma.duePayment.findUnique({
      where: { id: req.params.id }
    });

    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    if (payment.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.duePayment.delete({
      where: { id: req.params.id }
    });

    res.json({ message: 'Payment deleted successfully' });
  } catch (error) {
    next(error);
  }
};

const updatePaymentRecord = async (req, res, next) => {
  try {
    const { isPaid } = req.body;

    const record = await prisma.paymentRecord.findUnique({
      where: { id: req.params.recordId },
      include: { payment: true }
    });

    if (!record) {
      return res.status(404).json({ error: 'Payment record not found' });
    }

    if (record.payment.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.paymentRecord.update({
      where: { id: req.params.recordId },
      data: {
        isPaid: isPaid !== undefined ? isPaid : record.isPaid,
        paidAt: isPaid ? new Date() : null
      },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.json({
      message: 'Payment record updated',
      record: updated
    });
  } catch (error) {
    next(error);
  }
};

const addPaymentRecords = async (req, res, next) => {
  try {
    const { memberIds } = req.body;

    const payment = await prisma.duePayment.findUnique({
      where: { id: req.params.id }
    });

    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    if (payment.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const existingRecords = await prisma.paymentRecord.findMany({
      where: { paymentId: payment.id },
      select: { memberId: true }
    });

    const existingMemberIds = new Set(existingRecords.map(r => r.memberId));
    const newMemberIds = memberIds.filter(id => !existingMemberIds.has(id));

    const created = await prisma.paymentRecord.createMany({
      data: newMemberIds.map(memberId => ({
        paymentId: payment.id,
        memberId,
        isPaid: false
      }))
    });

    res.status(201).json({
      message: `Added ${created.count} payment records`,
      count: created.count
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getPayments,
  createPayment,
  getPayment,
  updatePayment,
  deletePayment,
  updatePaymentRecord,
  addPaymentRecords
};
