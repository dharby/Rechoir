const prisma = require('../config/database');

const getNotifications = async (req, res, next) => {
  try {
    let where = {};

    if (req.user.role === 'MEMBER') {
      where = { userId: req.user.id, userType: 'MEMBER' };
    } else if (req.user.role === 'TEAM_LEAD') {
      where = { userId: req.user.id, userType: 'TEAM_LEAD' };
    } else {
      return res.status(403).json({ error: 'Super admins do not have notifications' });
    }

    const notifications = await prisma.notification.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 50
    });

    const unreadCount = notifications.filter(n => !n.isRead).length;

    res.json({
      notifications,
      unreadCount
    });
  } catch (error) {
    next(error);
  }
};

const markNotificationRead = async (req, res, next) => {
  try {
    const notification = await prisma.notification.findUnique({
      where: { id: req.params.id }
    });

    if (!notification) {
      return res.status(404).json({ error: 'Notification not found' });
    }

    if (notification.userId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.notification.update({
      where: { id: req.params.id },
      data: {
        isRead: true,
        readAt: new Date()
      }
    });

    res.json({
      message: 'Notification marked as read',
      notification: updated
    });
  } catch (error) {
    next(error);
  }
};

const markAllNotificationsRead = async (req, res, next) => {
  try {
    let where = {};

    if (req.user.role === 'MEMBER') {
      where = { userId: req.user.id, userType: 'MEMBER' };
    } else if (req.user.role === 'TEAM_LEAD') {
      where = { userId: req.user.id, userType: 'TEAM_LEAD' };
    } else {
      return res.status(403).json({ error: 'Super admins do not have notifications' });
    }

    await prisma.notification.updateMany({
      where: { ...where, isRead: false },
      data: {
        isRead: true,
        readAt: new Date()
      }
    });

    res.json({ message: 'All notifications marked as read' });
  } catch (error) {
    next(error);
  }
};

const createNotification = async (userId, userType, title, body) => {
  try {
    await prisma.notification.create({
      data: {
        userId,
        userType,
        title,
        body
      }
    });
  } catch (error) {
    console.error('Failed to create notification:', error);
  }
};

const getUnreadCount = async (req, res, next) => {
  try {
    let where = {};

    if (req.user.role === 'MEMBER') {
      where = { userId: req.user.id, userType: 'MEMBER', isRead: false };
    } else if (req.user.role === 'TEAM_LEAD') {
      where = { userId: req.user.id, userType: 'TEAM_LEAD', isRead: false };
    } else {
      return res.status(403).json({ error: 'Super admins do not have notifications' });
    }

    const count = await prisma.notification.count({ where });

    res.json({ unreadCount: count });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  createNotification,
  getUnreadCount
};
