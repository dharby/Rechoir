const prisma = require('../config/database');
const { chatMessageSchema } = require('../utils/validation');

const getChatRooms = async (req, res, next) => {
  try {
    let rooms;

    if (req.user.role === 'SUPER_ADMIN') {
      rooms = [];
    } else if (req.user.role === 'TEAM_LEAD') {
      rooms = await prisma.chatRoom.findMany({
        where: { teamId: req.user.teamId },
        include: {
          _count: { select: { messages: true } },
          team: { select: { name: true } }
        },
        orderBy: { createdAt: 'asc' }
      });
    } else {
      const member = await prisma.member.findUnique({
        where: { id: req.user.id }
      });

      rooms = await prisma.chatRoom.findMany({
        where: { teamId: member.teamId },
        include: {
          _count: { select: { messages: true } },
          team: { select: { name: true } }
        },
        orderBy: { createdAt: 'asc' }
      });

      const specializationRoom = await prisma.chatRoom.findFirst({
        where: {
          teamId: member.teamId,
          type: 'GROUP',
          name: member.specialization
        }
      });

      if (!specializationRoom) {
        let groupRoom = await prisma.chatRoom.findFirst({
          where: {
            teamId: member.teamId,
            type: 'GROUP'
          }
        });

        if (!groupRoom) {
          groupRoom = await prisma.chatRoom.create({
            data: {
              name: member.specialization,
              type: 'GROUP',
              teamId: member.teamId
            }
          });
        }
      }
    }

    res.json(rooms);
  } catch (error) {
    next(error);
  }
};

const createChatRoom = async (req, res, next) => {
  try {
    const { name, type } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Room name is required' });
    }

    const room = await prisma.chatRoom.create({
      data: {
        name,
        type: type || 'GROUP',
        teamId: req.user.teamId
      }
    });

    res.status(201).json({
      message: 'Chat room created',
      room
    });
  } catch (error) {
    next(error);
  }
};

const getChatMessages = async (req, res, next) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const room = await prisma.chatRoom.findUnique({
      where: { id: req.params.id }
    });

    if (!room) {
      return res.status(404).json({ error: 'Chat room not found' });
    }

    if (room.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const messages = await prisma.chatMessage.findMany({
      where: { roomId: req.params.id },
      include: {
        sender: {
          select: { id: true, name: true, specialization: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: parseInt(limit)
    });

    const total = await prisma.chatMessage.count({
      where: { roomId: req.params.id }
    });

    res.json({
      messages: messages.reverse(),
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    next(error);
  }
};

const sendMessage = async (req, res, next) => {
  try {
    const data = chatMessageSchema.parse(req.body);

    const room = await prisma.chatRoom.findUnique({
      where: { id: req.params.id }
    });

    if (!room) {
      return res.status(404).json({ error: 'Chat room not found' });
    }

    if (room.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const senderType = req.user.role === 'TEAM_LEAD' ? 'TEAM_LEAD' : 'MEMBER';

    const message = await prisma.chatMessage.create({
      data: {
        roomId: req.params.id,
        senderId: req.user.id,
        senderType,
        content: data.content,
        type: data.type || 'TEXT'
      },
      include: {
        sender: {
          select: { id: true, name: true, specialization: true }
        }
      }
    });

    if (req.io) {
      req.io.to(`room:${room.id}`).emit('new-message', message);
    }

    res.status(201).json({
      message: 'Message sent',
      data: message
    });
  } catch (error) {
    next(error);
  }
};

const deleteMessage = async (req, res, next) => {
  try {
    const message = await prisma.chatMessage.findUnique({
      where: { id: req.params.messageId }
    });

    if (!message) {
      return res.status(404).json({ error: 'Message not found' });
    }

    if (message.senderId !== req.user.id && req.user.role !== 'TEAM_LEAD') {
      return res.status(403).json({ error: 'Cannot delete this message' });
    }

    await prisma.chatMessage.delete({
      where: { id: req.params.messageId }
    });

    if (req.io) {
      req.io.to(`room:${message.roomId}`).emit('message-deleted', { id: message.id });
    }

    res.json({ message: 'Message deleted' });
  } catch (error) {
    next(error);
  }
};

const markMessagesRead = async (req, res, next) => {
  try {
    const room = await prisma.chatRoom.findUnique({
      where: { id: req.params.id }
    });

    if (!room) {
      return res.status(404).json({ error: 'Chat room not found' });
    }

    if (room.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.chatMessage.updateMany({
      where: {
        roomId: req.params.id,
        readAt: null,
        senderId: { not: req.user.id }
      },
      data: { readAt: new Date() }
    });

    res.json({ message: 'Messages marked as read' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getChatRooms,
  createChatRoom,
  getChatMessages,
  sendMessage,
  deleteMessage,
  markMessagesRead
};
