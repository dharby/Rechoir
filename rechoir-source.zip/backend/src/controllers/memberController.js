const prisma = require('../config/database');
const { generateMemberAccessCode } = require('../utils/jwt');
const { memberSchema, bulkMemberSchema } = require('../utils/validation');
const XLSX = require('xlsx');

const getTeamMembers = async (req, res, next) => {
  try {
    const members = await prisma.member.findMany({
      where: { teamId: req.user.teamId },
      select: {
        id: true,
        email: true,
        name: true,
        phone: true,
        specialization: true,
        isActive: true,
        hasSetPassword: true,
        createdAt: true
      },
      orderBy: { name: 'asc' }
    });

    res.json(members);
  } catch (error) {
    next(error);
  }
};

const addMember = async (req, res, next) => {
  try {
    const data = memberSchema.parse(req.body);

    const existing = await prisma.member.findUnique({
      where: { email: data.email }
    });

    if (existing) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const accessCode = generateMemberAccessCode();

    const member = await prisma.member.create({
      data: {
        email: data.email,
        name: data.name,
        phone: data.phone,
        specialization: data.specialization || 'SINGER',
        accessCode,
        teamId: req.user.teamId
      },
      select: {
        id: true,
        email: true,
        name: true,
        phone: true,
        specialization: true,
        accessCode: true,
        createdAt: true
      }
    });

    res.status(201).json({
      message: 'Member added successfully',
      member
    });
  } catch (error) {
    next(error);
  }
};

const bulkImportMembers = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'File required' });
    }

    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    if (data.length === 0) {
      return res.status(400).json({ error: 'No data found in file' });
    }

    const processedMembers = [];
    const errors = [];

    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      
      const name = row.name || row.Name || row.NAME;
      const email = row.email || row.Email || row.EMAIL;
      const phone = row.phone || row.Phone || row.PHONE || null;
      const specialization = (row.specialization || row.Specialization || row.SPECIALIZATION || 'SINGER').toUpperCase();

      if (!name || !email) {
        errors.push({ row: i + 2, error: 'Name and email are required' });
        continue;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        errors.push({ row: i + 2, error: 'Invalid email format' });
        continue;
      }

      if (!['SINGER', 'INSTRUMENTALIST', 'TEAM_LEAD', 'OFFICER'].includes(specialization)) {
        errors.push({ row: i + 2, error: 'Invalid specialization' });
        continue;
      }

      processedMembers.push({
        name,
        email,
        phone,
        specialization
      });
    }

    if (errors.length > 0 && processedMembers.length === 0) {
      return res.status(400).json({ 
        error: 'All rows have errors',
        errors 
      });
    }

    const existingEmails = await prisma.member.findMany({
      where: {
        email: { in: processedMembers.map(m => m.email) }
      },
      select: { email: true }
    });

    const existingEmailSet = new Set(existingEmails.map(e => e.email));
    const newMembers = processedMembers.filter(m => !existingEmailSet.has(m.email));
    const skipped = processedMembers.filter(m => existingEmailSet.has(m.email));

    const createdMembers = await prisma.$transaction(
      newMembers.map(m => 
        prisma.member.create({
          data: {
            email: m.email,
            name: m.name,
            phone: m.phone,
            specialization: m.specialization,
            accessCode: generateMemberAccessCode(),
            teamId: req.user.teamId
          }
        })
      )
    );

    res.status(201).json({
      message: `Imported ${createdMembers.length} members`,
      imported: createdMembers.length,
      skipped: skipped.length,
      errors: errors.length,
      details: {
        members: createdMembers.map(m => ({
          id: m.id,
          email: m.email,
          name: m.name,
          specialization: m.specialization
        })),
        skippedEmails: skipped.map(m => m.email),
        rowErrors: errors
      }
    });
  } catch (error) {
    next(error);
  }
};

const previewBulkImport = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'File required' });
    }

    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    if (data.length === 0) {
      return res.status(400).json({ error: 'No data found in file' });
    }

    const preview = data.slice(0, 10).map((row, i) => ({
      row: i + 2,
      name: row.name || row.Name || row.NAME || 'MISSING',
      email: row.email || row.Email || row.EMAIL || 'MISSING',
      phone: row.phone || row.Phone || row.PHONE || null,
      specialization: row.specialization || row.Specialization || row.SPECIALIZATION || 'SINGER'
    }));

    res.json({
      totalRows: data.length,
      preview
    });
  } catch (error) {
    next(error);
  }
};

const getMember = async (req, res, next) => {
  try {
    const member = await prisma.member.findUnique({
      where: { id: req.params.id },
      select: {
        id: true,
        email: true,
        name: true,
        phone: true,
        specialization: true,
        isActive: true,
        hasSetPassword: true,
        createdAt: true,
        _count: {
          select: {
            attendance: true,
            songAssignments: true
          }
        }
      }
    });

    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    if (member.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(member);
  } catch (error) {
    next(error);
  }
};

const updateMember = async (req, res, next) => {
  try {
    const { name, phone, specialization } = req.body;

    const member = await prisma.member.findUnique({
      where: { id: req.params.id }
    });

    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    if (member.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.member.update({
      where: { id: req.params.id },
      data: {
        name: name || member.name,
        phone: phone !== undefined ? phone : member.phone,
        specialization: specialization || member.specialization
      },
      select: {
        id: true,
        email: true,
        name: true,
        phone: true,
        specialization: true,
        isActive: true,
        createdAt: true
      }
    });

    res.json({
      message: 'Member updated successfully',
      member: updated
    });
  } catch (error) {
    next(error);
  }
};

const toggleMemberAccess = async (req, res, next) => {
  try {
    const member = await prisma.member.findUnique({
      where: { id: req.params.id }
    });

    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    if (member.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.member.update({
      where: { id: req.params.id },
      data: { isActive: !member.isActive },
      select: {
        id: true,
        email: true,
        name: true,
        isActive: true
      }
    });

    res.json({
      message: `Member access ${updated.isActive ? 'enabled' : 'disabled'}`,
      member: updated
    });
  } catch (error) {
    next(error);
  }
};

const removeMember = async (req, res, next) => {
  try {
    const member = await prisma.member.findUnique({
      where: { id: req.params.id }
    });

    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    if (member.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.member.delete({
      where: { id: req.params.id }
    });

    res.json({ message: 'Member removed successfully' });
  } catch (error) {
    next(error);
  }
};

const regenerateAccessCode = async (req, res, next) => {
  try {
    const member = await prisma.member.findUnique({
      where: { id: req.params.id }
    });

    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    if (member.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const newAccessCode = generateMemberAccessCode();

    await prisma.member.update({
      where: { id: req.params.id },
      data: {
        accessCode: newAccessCode,
        hasSetPassword: false
      }
    });

    res.json({
      message: 'Access code regenerated',
      accessCode: newAccessCode,
      member: {
        id: member.id,
        email: member.email,
        name: member.name
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getTeamMembers,
  addMember,
  bulkImportMembers,
  previewBulkImport,
  getMember,
  updateMember,
  toggleMemberAccess,
  removeMember,
  regenerateAccessCode
};
