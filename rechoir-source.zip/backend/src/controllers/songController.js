const prisma = require('../config/database');
const { songSchema, songAssignmentSchema } = require('../utils/validation');

const getSongs = async (req, res, next) => {
  try {
    const songs = await prisma.song.findMany({
      where: { teamId: req.user.teamId },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        },
        _count: { select: { assignments: true } }
      },
      orderBy: { targetReadinessDate: 'asc' }
    });

    const songsWithReadiness = songs.map(song => {
      const total = song.assignments.length;
      const ready = song.assignments.filter(a => a.status === 'READY' || a.status === 'PERFECT').length;
      const learning = song.assignments.filter(a => a.status === 'LEARNING').length;
      const notStarted = song.assignments.filter(a => a.status === 'NOT_STARTED').length;
      
      let status = 'NOT_STARTED';
      if (ready === total && total > 0) status = 'ALL_READY';
      else if (ready >= total * 0.6) status = 'MOSTLY_READY';
      else if (learning > 0) status = 'IN_PROGRESS';
      else if (ready > 0) status = 'PARTIAL';

      const daysUntil = Math.ceil((new Date(song.targetReadinessDate) - new Date()) / (1000 * 60 * 60 * 24));

      return {
        ...song,
        stats: { ready, learning, notStarted, total },
        status,
        daysUntil: daysUntil > 0 ? daysUntil : 0
      };
    });

    res.json(songsWithReadiness);
  } catch (error) {
    next(error);
  }
};

const createSong = async (req, res, next) => {
  try {
    const data = songSchema.parse(req.body);

    const song = await prisma.song.create({
      data: {
        title: data.title,
        key: data.key,
        youtubeUrl: data.youtubeUrl,
        practiceNotes: data.practiceNotes,
        targetReadinessDate: new Date(data.targetReadinessDate),
        teamId: req.user.teamId,
        assignments: data.memberIds ? {
          create: data.memberIds.map(memberId => ({
            memberId,
            status: 'NOT_STARTED'
          }))
        } : undefined
      },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.status(201).json({
      message: 'Song created successfully',
      song
    });
  } catch (error) {
    next(error);
  }
};

const getSong = async (req, res, next) => {
  try {
    const song = await prisma.song.findUnique({
      where: { id: req.params.id },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        }
      }
    });

    if (!song) {
      return res.status(404).json({ error: 'Song not found' });
    }

    if (song.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const total = song.assignments.length;
    const ready = song.assignments.filter(a => a.status === 'READY' || a.status === 'PERFECT').length;
    const daysUntil = Math.ceil((new Date(song.targetReadinessDate) - new Date()) / (1000 * 60 * 60 * 24));

    res.json({
      ...song,
      stats: { ready, total },
      daysUntil: daysUntil > 0 ? daysUntil : 0
    });
  } catch (error) {
    next(error);
  }
};

const updateSong = async (req, res, next) => {
  try {
    const { title, key, youtubeUrl, practiceNotes, targetReadinessDate } = req.body;

    const song = await prisma.song.findUnique({
      where: { id: req.params.id }
    });

    if (!song) {
      return res.status(404).json({ error: 'Song not found' });
    }

    if (song.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.song.update({
      where: { id: req.params.id },
      data: {
        title: title || song.title,
        key: key !== undefined ? key : song.key,
        youtubeUrl: youtubeUrl !== undefined ? youtubeUrl : song.youtubeUrl,
        practiceNotes: practiceNotes !== undefined ? practiceNotes : song.practiceNotes,
        targetReadinessDate: targetReadinessDate ? new Date(targetReadinessDate) : song.targetReadinessDate
      },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.json({
      message: 'Song updated successfully',
      song: updated
    });
  } catch (error) {
    next(error);
  }
};

const deleteSong = async (req, res, next) => {
  try {
    const song = await prisma.song.findUnique({
      where: { id: req.params.id }
    });

    if (!song) {
      return res.status(404).json({ error: 'Song not found' });
    }

    if (song.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.song.delete({
      where: { id: req.params.id }
    });

    res.json({ message: 'Song deleted successfully' });
  } catch (error) {
    next(error);
  }
};

const assignSong = async (req, res, next) => {
  try {
    const { memberId } = req.body;

    const song = await prisma.song.findUnique({
      where: { id: req.params.id }
    });

    if (!song) {
      return res.status(404).json({ error: 'Song not found' });
    }

    if (song.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const member = await prisma.member.findUnique({
      where: { id: memberId }
    });

    if (!member || member.teamId !== req.user.teamId) {
      return res.status(404).json({ error: 'Member not found in your team' });
    }

    const assignment = await prisma.songAssignment.create({
      data: {
        songId: song.id,
        memberId,
        status: 'NOT_STARTED'
      },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.status(201).json({
      message: 'Member assigned to song',
      assignment
    });
  } catch (error) {
    if (error.code === 'P2002') {
      return res.status(409).json({ error: 'Member already assigned to this song' });
    }
    next(error);
  }
};

const updateSongAssignment = async (req, res, next) => {
  try {
    const data = songAssignmentSchema.parse(req.body);

    const assignment = await prisma.songAssignment.findUnique({
      where: { id: req.params.assignmentId },
      include: { song: true }
    });

    if (!assignment) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    if (assignment.song.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.songAssignment.update({
      where: { id: req.params.assignmentId },
      data: {
        status: data.status,
        note: data.note !== undefined ? data.note : assignment.note
      },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.json({
      message: 'Readiness status updated',
      assignment: updated
    });
  } catch (error) {
    next(error);
  }
};

const updateSongAssignmentByMember = async (req, res, next) => {
  try {
    const data = songAssignmentSchema.parse(req.body);

    const assignment = await prisma.songAssignment.findUnique({
      where: { 
        songId_memberId: {
          songId: req.params.id,
          memberId: req.user.id
        }
      },
      include: { song: true }
    });

    if (!assignment) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    if (assignment.song.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.songAssignment.update({
      where: { id: assignment.id },
      data: {
        status: data.status,
        note: data.note !== undefined ? data.note : assignment.note
      }
    });

    res.json({
      message: 'Your readiness status updated',
      assignment: updated
    });
  } catch (error) {
    next(error);
  }
};

const removeSongAssignment = async (req, res, next) => {
  try {
    const assignment = await prisma.songAssignment.findUnique({
      where: { id: req.params.assignmentId },
      include: { song: true }
    });

    if (!assignment) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    if (assignment.song.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.songAssignment.delete({
      where: { id: req.params.assignmentId }
    });

    res.json({ message: 'Assignment removed' });
  } catch (error) {
    next(error);
  }
};

const getWeeklySongReadiness = async (req, res, next) => {
  try {
    const today = new Date();
    const endOfWeek = new Date(today);
    endOfWeek.setDate(today.getDate() + (7 - today.getDay()));

    const songs = await prisma.song.findMany({
      where: {
        teamId: req.user.teamId,
        targetReadinessDate: {
          lte: endOfWeek
        }
      },
      include: {
        assignments: {
          include: {
            member: {
              select: { id: true, name: true, specialization: true }
            }
          }
        }
      }
    });

    const readiness = songs.map(song => {
      const total = song.assignments.length;
      const ready = song.assignments.filter(a => a.status === 'READY' || a.status === 'PERFECT').length;
      const percentage = total > 0 ? Math.round((ready / total) * 100) : 0;
      
      return {
        id: song.id,
        title: song.title,
        key: song.key,
        targetDate: song.targetReadinessDate,
        daysUntil: Math.ceil((new Date(song.targetReadinessDate) - new Date()) / (1000 * 60 * 60 * 24)),
        stats: { ready, total, percentage },
        status: percentage >= 60 ? 'ON_TRACK' : percentage >= 30 ? 'AT_RISK' : 'BEHIND',
        membersNeedingAttention: song.assignments
          .filter(a => a.status === 'NOT_STARTED' || a.status === 'LEARNING')
          .map(a => ({
            id: a.member.id,
            name: a.member.name,
            specialization: a.member.specialization,
            status: a.status
          }))
      };
    });

    res.json({
      weekEnding: endOfWeek,
      songs: readiness.sort((a, b) => a.daysUntil - b.daysUntil)
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getSongs,
  createSong,
  getSong,
  updateSong,
  deleteSong,
  assignSong,
  updateSongAssignment,
  updateSongAssignmentByMember,
  removeSongAssignment,
  getWeeklySongReadiness
};
