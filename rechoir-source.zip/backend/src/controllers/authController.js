const bcrypt = require('bcryptjs');
const prisma = require('../config/database');
const config = require('../config');
const { 
  generateAccessToken, 
  generateRefreshToken, 
  verifyRefreshToken,
  generateTeamCode,
  generateMemberAccessCode 
} = require('../utils/jwt');
const { 
  superAdminRegisterSchema, 
  superAdminLoginSchema,
  teamLeadRegisterSchema,
  teamLeadLoginSchema,
  memberLoginSchema,
  setMemberPasswordSchema
} = require('../utils/validation');

const superAdminRegister = async (req, res, next) => {
  try {
    const data = superAdminRegisterSchema.parse(req.body);

    const existing = await prisma.superAdmin.findUnique({
      where: { email: data.email }
    });

    if (existing) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(data.password, config.bcrypt.saltRounds);

    const superAdmin = await prisma.superAdmin.create({
      data: {
        email: data.email,
        password: passwordHash,
        name: data.name
      }
    });

    const accessToken = generateAccessToken({
      id: superAdmin.id,
      email: superAdmin.email,
      role: 'SUPER_ADMIN'
    });

    const refreshToken = generateRefreshToken({
      id: superAdmin.id,
      role: 'SUPER_ADMIN'
    });

    res.status(201).json({
      message: 'Super admin registered successfully',
      accessToken,
      refreshToken,
      user: {
        id: superAdmin.id,
        email: superAdmin.email,
        name: superAdmin.name,
        role: 'SUPER_ADMIN'
      }
    });
  } catch (error) {
    next(error);
  }
};

const superAdminLogin = async (req, res, next) => {
  try {
    const data = superAdminLoginSchema.parse(req.body);

    const superAdmin = await prisma.superAdmin.findUnique({
      where: { email: data.email }
    });

    if (!superAdmin) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(data.password, superAdmin.password);

    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const accessToken = generateAccessToken({
      id: superAdmin.id,
      email: superAdmin.email,
      role: 'SUPER_ADMIN'
    });

    const refreshToken = generateRefreshToken({
      id: superAdmin.id,
      role: 'SUPER_ADMIN'
    });

    res.json({
      accessToken,
      refreshToken,
      user: {
        id: superAdmin.id,
        email: superAdmin.email,
        name: superAdmin.name,
        role: 'SUPER_ADMIN'
      }
    });
  } catch (error) {
    next(error);
  }
};

const teamLeadRegister = async (req, res, next) => {
  try {
    const data = teamLeadRegisterSchema.parse(req.body);

    const existing = await prisma.teamLead.findUnique({
      where: { email: data.email }
    });

    if (existing) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(data.password, config.bcrypt.saltRounds);

    const result = await prisma.$transaction(async (tx) => {
      const team = await tx.team.create({
        data: {
          name: data.teamName,
          code: generateTeamCode(),
          superAdminId: req.user.id
        }
      });

      const teamLead = await tx.teamLead.create({
        data: {
          email: data.email,
          password: passwordHash,
          name: data.name,
          phone: data.phone,
          teamId: team.id
        }
      });

      await tx.chatRoom.create({
        data: {
          name: 'General',
          type: 'TEAM',
          teamId: team.id
        }
      });

      return { team, teamLead };
    });

    const accessToken = generateAccessToken({
      id: result.teamLead.id,
      email: result.teamLead.email,
      role: 'TEAM_LEAD',
      teamId: result.team.id
    });

    const refreshToken = generateRefreshToken({
      id: result.teamLead.id,
      role: 'TEAM_LEAD',
      teamId: result.team.id
    });

    res.status(201).json({
      message: 'Team lead registered successfully',
      accessToken,
      refreshToken,
      team: {
        id: result.team.id,
        name: result.team.name,
        code: result.team.code
      },
      user: {
        id: result.teamLead.id,
        email: result.teamLead.email,
        name: result.teamLead.name,
        role: 'TEAM_LEAD'
      }
    });
  } catch (error) {
    next(error);
  }
};

const teamLeadLogin = async (req, res, next) => {
  try {
    const data = teamLeadLoginSchema.parse(req.body);

    const teamLead = await prisma.teamLead.findUnique({
      where: { email: data.email },
      include: { team: true }
    });

    if (!teamLead) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(data.password, teamLead.password);

    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (!teamLead.isActive) {
      return res.status(403).json({ error: 'Account has been disabled' });
    }

    const accessToken = generateAccessToken({
      id: teamLead.id,
      email: teamLead.email,
      role: 'TEAM_LEAD',
      teamId: teamLead.teamId
    });

    const refreshToken = generateRefreshToken({
      id: teamLead.id,
      role: 'TEAM_LEAD',
      teamId: teamLead.teamId
    });

    res.json({
      accessToken,
      refreshToken,
      team: {
        id: teamLead.team.id,
        name: teamLead.team.name,
        code: teamLead.team.code
      },
      user: {
        id: teamLead.id,
        email: teamLead.email,
        name: teamLead.name,
        role: 'TEAM_LEAD'
      }
    });
  } catch (error) {
    next(error);
  }
};

const memberLogin = async (req, res, next) => {
  try {
    const data = memberLoginSchema.parse(req.body);

    const member = await prisma.member.findUnique({
      where: { email: data.email },
      include: { team: true }
    });

    if (!member) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (!member.isActive) {
      return res.status(403).json({ error: 'Access has been disabled' });
    }

    if (member.hasSetPassword) {
      return res.status(400).json({ 
        error: 'Password required',
        requiresPassword: true 
      });
    }

    if (member.accessCode !== data.accessCode) {
      return res.status(401).json({ error: 'Invalid access code' });
    }

    const accessToken = generateAccessToken({
      id: member.id,
      email: member.email,
      role: 'MEMBER',
      teamId: member.teamId
    });

    const refreshToken = generateRefreshToken({
      id: member.id,
      role: 'MEMBER',
      teamId: member.teamId
    });

    res.json({
      accessToken,
      refreshToken,
      requiresPassword: false,
      team: {
        id: member.team.id,
        name: member.team.name,
        code: member.team.code
      },
      user: {
        id: member.id,
        email: member.email,
        name: member.name,
        role: 'MEMBER'
      }
    });
  } catch (error) {
    next(error);
  }
};

const memberLoginWithPassword = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const member = await prisma.member.findUnique({
      where: { email },
      include: { team: true }
    });

    if (!member) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (!member.isActive) {
      return res.status(403).json({ error: 'Access has been disabled' });
    }

    if (!member.hasSetPassword) {
      return res.status(400).json({ 
        error: 'Please use access code first',
        requiresPassword: false 
      });
    }

    const validPassword = await bcrypt.compare(password, member.accessCode);

    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const accessToken = generateAccessToken({
      id: member.id,
      email: member.email,
      role: 'MEMBER',
      teamId: member.teamId
    });

    const refreshToken = generateRefreshToken({
      id: member.id,
      role: 'MEMBER',
      teamId: member.teamId
    });

    res.json({
      accessToken,
      refreshToken,
      requiresPassword: false,
      team: {
        id: member.team.id,
        name: member.team.name,
        code: member.team.code
      },
      user: {
        id: member.id,
        email: member.email,
        name: member.name,
        role: 'MEMBER'
      }
    });
  } catch (error) {
    next(error);
  }
};

const setMemberPassword = async (req, res, next) => {
  try {
    const data = setMemberPasswordSchema.parse(req.body);

    const member = await prisma.member.findUnique({
      where: { email: req.user.email }
    });

    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    if (member.accessCode !== data.accessCode) {
      return res.status(401).json({ error: 'Invalid access code' });
    }

    const passwordHash = await bcrypt.hash(data.password, config.bcrypt.saltRounds);

    await prisma.member.update({
      where: { id: member.id },
      data: {
        accessCode: passwordHash,
        hasSetPassword: true
      }
    });

    res.json({ message: 'Password set successfully' });
  } catch (error) {
    next(error);
  }
};

const refreshToken = async (req, res, next) => {
  try {
    const { refreshToken: token } = req.body;

    if (!token) {
      return res.status(400).json({ error: 'Refresh token required' });
    }

    const decoded = verifyRefreshToken(token);

    const accessToken = generateAccessToken({
      id: decoded.id,
      email: decoded.email,
      role: decoded.role,
      teamId: decoded.teamId
    });

    const newRefreshToken = generateRefreshToken({
      id: decoded.id,
      role: decoded.role,
      teamId: decoded.teamId
    });

    res.json({
      accessToken,
      refreshToken: newRefreshToken
    });
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Refresh token expired' });
    }
    next(error);
  }
};

module.exports = {
  superAdminRegister,
  superAdminLogin,
  teamLeadRegister,
  teamLeadLogin,
  memberLogin,
  memberLoginWithPassword,
  setMemberPassword,
  refreshToken
};
