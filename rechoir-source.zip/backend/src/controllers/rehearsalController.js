const prisma = require('../config/database');
const { rehearsalSchema, attendanceSchema } = require('../utils/validation');

const getRehearsals = async (req, res, next) => {
  try {
    const { startDate, endDate } = req.query;
    
    const where = { teamId: req.user.teamId };
    
    if (startDate && endDate) {
      where.date = {
        gte: new Date(startDate),
        lte: new Date(endDate)
      };
    }

    const rehearsals = await prisma.rehearsal.findMany({
      where,
      include: {
        attendance: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        },
        _count: { select: { attendance: true } }
      },
      orderBy: { date: 'desc' }
    });

    const rehearsalsWithStats = rehearsals.map(rehearsal => {
      const present = rehearsal.attendance.filter(a => a.status === 'PRESENT').length;
      const absent = rehearsal.attendance.filter(a => a.status === 'ABSENT').length;
      const excused = rehearsal.attendance.filter(a => a.status === 'EXCUSED').length;
      return {
        ...rehearsal,
        stats: { present, absent, excused, total: rehearsal.attendance.length }
      };
    });

    res.json(rehearsalsWithStats);
  } catch (error) {
    next(error);
  }
};

const createRehearsal = async (req, res, next) => {
  try {
    const data = rehearsalSchema.parse(req.body);

    const rehearsal = await prisma.rehearsal.create({
      data: {
        title: data.title,
        date: new Date(data.date),
        startTime: data.startTime,
        endTime: data.endTime,
        location: data.location,
        agenda: data.agenda,
        teamId: req.user.teamId
      }
    });

    const members = await prisma.member.findMany({
      where: { teamId: req.user.teamId, isActive: true },
      select: { id: true }
    });

    await prisma.attendance.createMany({
      data: members.map(m => ({
        rehearsalId: rehearsal.id,
        memberId: m.id,
        status: 'ABSENT'
      }))
    });

    const created = await prisma.rehearsal.findUnique({
      where: { id: rehearsal.id },
      include: {
        attendance: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.status(201).json({
      message: 'Rehearsal created and attendance initialized',
      rehearsal: created
    });
  } catch (error) {
    next(error);
  }
};

const getRehearsal = async (req, res, next) => {
  try {
    const rehearsal = await prisma.rehearsal.findUnique({
      where: { id: req.params.id },
      include: {
        attendance: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        }
      }
    });

    if (!rehearsal) {
      return res.status(404).json({ error: 'Rehearsal not found' });
    }

    if (rehearsal.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(rehearsal);
  } catch (error) {
    next(error);
  }
};

const updateRehearsal = async (req, res, next) => {
  try {
    const { title, date, startTime, endTime, location, agenda } = req.body;

    const rehearsal = await prisma.rehearsal.findUnique({
      where: { id: req.params.id }
    });

    if (!rehearsal) {
      return res.status(404).json({ error: 'Rehearsal not found' });
    }

    if (rehearsal.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.rehearsal.update({
      where: { id: req.params.id },
      data: {
        title: title || rehearsal.title,
        date: date ? new Date(date) : rehearsal.date,
        startTime: startTime || rehearsal.startTime,
        endTime: endTime || rehearsal.endTime,
        location: location !== undefined ? location : rehearsal.location,
        agenda: agenda !== undefined ? agenda : rehearsal.agenda
      },
      include: {
        attendance: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.json({
      message: 'Rehearsal updated successfully',
      rehearsal: updated
    });
  } catch (error) {
    next(error);
  }
};

const deleteRehearsal = async (req, res, next) => {
  try {
    const rehearsal = await prisma.rehearsal.findUnique({
      where: { id: req.params.id }
    });

    if (!rehearsal) {
      return res.status(404).json({ error: 'Rehearsal not found' });
    }

    if (rehearsal.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.rehearsal.delete({
      where: { id: req.params.id }
    });

    res.json({ message: 'Rehearsal deleted successfully' });
  } catch (error) {
    next(error);
  }
};

const markAttendance = async (req, res, next) => {
  try {
    const data = attendanceSchema.parse(req.body);

    const rehearsal = await prisma.rehearsal.findUnique({
      where: { id: req.params.id }
    });

    if (!rehearsal) {
      return res.status(404).json({ error: 'Rehearsal not found' });
    }

    if (rehearsal.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const member = await prisma.member.findUnique({
      where: { id: data.memberId }
    });

    if (!member || member.teamId !== req.user.teamId) {
      return res.status(404).json({ error: 'Member not found in your team' });
    }

    const attendance = await prisma.attendance.upsert({
      where: {
        rehearsalId_memberId: {
          rehearsalId: req.params.id,
          memberId: data.memberId
        }
      },
      update: {
        status: data.status,
        arrivalTime: data.arrivalTime ? new Date(data.arrivalTime) : null
      },
      create: {
        rehearsalId: req.params.id,
        memberId: data.memberId,
        status: data.status,
        arrivalTime: data.arrivalTime ? new Date(data.arrivalTime) : null
      },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.json({
      message: 'Attendance marked successfully',
      attendance
    });
  } catch (error) {
    next(error);
  }
};

const getAttendanceReport = async (req, res, next) => {
  try {
    const { memberId } = req.params;

    const member = await prisma.member.findUnique({
      where: { id: memberId }
    });

    if (!member || member.teamId !== req.user.teamId) {
      return res.status(404).json({ error: 'Member not found' });
    }

    const attendance = await prisma.attendance.findMany({
      where: { memberId },
      include: {
        rehearsal: {
          select: { title: true, date: true }
        }
      },
      orderBy: { rehearsal: { date: 'desc' } }
    });

    const total = attendance.length;
    const present = attendance.filter(a => a.status === 'PRESENT').length;
    const absent = attendance.filter(a => a.status === 'ABSENT').length;
    const excused = attendance.filter(a => a.status === 'EXCUSED').length;
    const rate = total > 0 ? Math.round((present / total) * 100) : 0;

    res.json({
      member: {
        id: member.id,
        name: member.name,
        email: member.email
      },
      stats: {
        total,
        present,
        absent,
        excused,
        attendanceRate: rate
      },
      history: attendance
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getRehearsals,
  createRehearsal,
  getRehearsal,
  updateRehearsal,
  deleteRehearsal,
  markAttendance,
  getAttendanceReport
};
