const prisma = require('../config/database');
const { generateTeamCode } = require('../utils/jwt');

const getTeams = async (req, res, next) => {
  try {
    const teams = await prisma.team.findMany({
      where: { superAdminId: req.user.id },
      include: {
        teamLead: {
          select: { id: true, name: true, email: true, phone: true }
        },
        _count: {
          select: { members: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json(teams);
  } catch (error) {
    next(error);
  }
};

const createTeam = async (req, res, next) => {
  try {
    const { name } = req.body;

    if (!name || name.length < 2) {
      return res.status(400).json({ error: 'Team name must be at least 2 characters' });
    }

    const team = await prisma.team.create({
      data: {
        name,
        code: generateTeamCode(),
        superAdminId: req.user.id
      }
    });

    res.status(201).json({
      message: 'Team created successfully',
      team
    });
  } catch (error) {
    next(error);
  }
};

const getTeam = async (req, res, next) => {
  try {
    const team = await prisma.team.findUnique({
      where: { id: req.params.id },
      include: {
        teamLead: {
          select: { id: true, name: true, email: true, phone: true }
        },
        members: {
          select: {
            id: true,
            name: true,
            email: true,
            specialization: true,
            isActive: true
          }
        },
        _count: {
          select: {
            members: true,
            prayerChains: true,
            payments: true,
            rehearsals: true,
            songs: true
          }
        }
      }
    });

    if (!team) {
      return res.status(404).json({ error: 'Team not found' });
    }

    if (team.superAdminId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(team);
  } catch (error) {
    next(error);
  }
};

const updateTeam = async (req, res, next) => {
  try {
    const { name } = req.body;

    const team = await prisma.team.findUnique({
      where: { id: req.params.id }
    });

    if (!team) {
      return res.status(404).json({ error: 'Team not found' });
    }

    if (team.superAdminId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.team.update({
      where: { id: req.params.id },
      data: {
        name: name || team.name
      }
    });

    res.json({
      message: 'Team updated successfully',
      team: updated
    });
  } catch (error) {
    next(error);
  }
};

const deleteTeam = async (req, res, next) => {
  try {
    const team = await prisma.team.findUnique({
      where: { id: req.params.id }
    });

    if (!team) {
      return res.status(404).json({ error: 'Team not found' });
    }

    if (team.superAdminId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.team.delete({
      where: { id: req.params.id }
    });

    res.json({ message: 'Team deleted successfully' });
  } catch (error) {
    next(error);
  }
};

const getTeamStats = async (req, res, next) => {
  try {
    const team = await prisma.team.findUnique({
      where: { id: req.params.id }
    });

    if (!team) {
      return res.status(404).json({ error: 'Team not found' });
    }

    if (team.superAdminId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const [
      memberCount,
      activeChains,
      pendingPayments,
      upcomingRehearsals,
      songCount
    ] = await Promise.all([
      prisma.member.count({ where: { teamId: team.id } }),
      prisma.prayerChain.count({ 
        where: { teamId: team.id },
        include: { assignments: true }
      }),
      prisma.duePayment.count({ 
        where: { 
          teamId: team.id,
          dueDate: { gte: new Date() }
        }
      }),
      prisma.rehearsal.count({ 
        where: { 
          teamId: team.id,
          date: { gte: new Date() }
        }
      }),
      prisma.song.count({ where: { teamId: team.id } })
    ]);

    res.json({
      team: {
        id: team.id,
        name: team.name,
        code: team.code
      },
      stats: {
        members: memberCount,
        activePrayerChains: activeChains,
        pendingPayments,
        upcomingRehearsals,
        songs: songCount
      }
    });
  } catch (error) {
    next(error);
  }
};

const getPlatformStats = async (req, res, next) => {
  try {
    const [
      teamCount,
      totalMembers,
      activeTeams,
      totalRehearsals,
      totalSongs
    ] = await Promise.all([
      prisma.team.count({ where: { superAdminId: req.user.id } }),
      prisma.member.count({
        where: { team: { superAdminId: req.user.id } }
      }),
      prisma.team.count({ 
        where: { 
          superAdminId: req.user.id,
          teamLead: { isActive: true }
        } 
      }),
      prisma.rehearsal.count({
        where: { team: { superAdminId: req.user.id } }
      }),
      prisma.song.count({
        where: { team: { superAdminId: req.user.id } }
      })
    ]);

    res.json({
      stats: {
        totalTeams: teamCount,
        activeTeams,
        totalMembers,
        totalRehearsals,
        totalSongs
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getTeams,
  createTeam,
  getTeam,
  updateTeam,
  deleteTeam,
  getTeamStats,
  getPlatformStats
};
