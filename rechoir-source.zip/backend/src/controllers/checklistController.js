const prisma = require('../config/database');
const { weeklyChecklistSchema, checklistItemSchema } = require('../utils/validation');

const getChecklists = async (req, res, next) => {
  try {
    const checklists = await prisma.weeklyChecklist.findMany({
      where: { teamId: req.user.teamId },
      include: {
        items: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        },
        _count: { select: { items: true } }
      },
      orderBy: { weekStartDate: 'desc' }
    });

    const checklistsWithProgress = checklists.map(checklist => {
      const total = checklist.items.length;
      const completed = checklist.items.filter(i => i.isCompleted).length;
      return {
        ...checklist,
        progress: { completed, total, percentage: total > 0 ? Math.round((completed / total) * 100) : 0 }
      };
    });

    res.json(checklistsWithProgress);
  } catch (error) {
    next(error);
  }
};

const createChecklist = async (req, res, next) => {
  try {
    const data = weeklyChecklistSchema.parse(req.body);

    const checklist = await prisma.weeklyChecklist.create({
      data: {
        title: data.title,
        weekStartDate: new Date(data.weekStartDate),
        teamId: req.user.teamId,
        items: data.items ? {
          create: data.items.map(item => ({
            memberId: item.memberId,
            description: item.description,
            isCompleted: false
          }))
        } : undefined
      },
      include: {
        items: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.status(201).json({
      message: 'Checklist created successfully',
      checklist
    });
  } catch (error) {
    next(error);
  }
};

const getChecklist = async (req, res, next) => {
  try {
    const checklist = await prisma.weeklyChecklist.findUnique({
      where: { id: req.params.id },
      include: {
        items: {
          include: {
            member: {
              select: { id: true, name: true, email: true, specialization: true }
            }
          }
        }
      }
    });

    if (!checklist) {
      return res.status(404).json({ error: 'Checklist not found' });
    }

    if (checklist.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const total = checklist.items.length;
    const completed = checklist.items.filter(i => i.isCompleted).length;

    res.json({
      ...checklist,
      progress: { completed, total, percentage: total > 0 ? Math.round((completed / total) * 100) : 0 }
    });
  } catch (error) {
    next(error);
  }
};

const updateChecklist = async (req, res, next) => {
  try {
    const { title, weekStartDate } = req.body;

    const checklist = await prisma.weeklyChecklist.findUnique({
      where: { id: req.params.id }
    });

    if (!checklist) {
      return res.status(404).json({ error: 'Checklist not found' });
    }

    if (checklist.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.weeklyChecklist.update({
      where: { id: req.params.id },
      data: {
        title: title || checklist.title,
        weekStartDate: weekStartDate ? new Date(weekStartDate) : checklist.weekStartDate
      },
      include: {
        items: {
          include: {
            member: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      }
    });

    res.json({
      message: 'Checklist updated successfully',
      checklist: updated
    });
  } catch (error) {
    next(error);
  }
};

const deleteChecklist = async (req, res, next) => {
  try {
    const checklist = await prisma.weeklyChecklist.findUnique({
      where: { id: req.params.id }
    });

    if (!checklist) {
      return res.status(404).json({ error: 'Checklist not found' });
    }

    if (checklist.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.weeklyChecklist.delete({
      where: { id: req.params.id }
    });

    res.json({ message: 'Checklist deleted successfully' });
  } catch (error) {
    next(error);
  }
};

const addChecklistItem = async (req, res, next) => {
  try {
    const { memberId, description } = req.body;

    const checklist = await prisma.weeklyChecklist.findUnique({
      where: { id: req.params.id }
    });

    if (!checklist) {
      return res.status(404).json({ error: 'Checklist not found' });
    }

    if (checklist.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const member = await prisma.member.findUnique({
      where: { id: memberId }
    });

    if (!member || member.teamId !== req.user.teamId) {
      return res.status(404).json({ error: 'Member not found in your team' });
    }

    const item = await prisma.checklistItem.create({
      data: {
        checklistId: checklist.id,
        memberId,
        description,
        isCompleted: false
      },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.status(201).json({
      message: 'Item added successfully',
      item
    });
  } catch (error) {
    next(error);
  }
};

const toggleChecklistItem = async (req, res, next) => {
  try {
    const item = await prisma.checklistItem.findUnique({
      where: { id: req.params.itemId },
      include: { checklist: true }
    });

    if (!item) {
      return res.status(404).json({ error: 'Item not found' });
    }

    if (item.checklist.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const updated = await prisma.checklistItem.update({
      where: { id: req.params.itemId },
      data: {
        isCompleted: !item.isCompleted,
        completedAt: !item.isCompleted ? new Date() : null
      },
      include: {
        member: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    res.json({
      message: `Item marked as ${updated.isCompleted ? 'completed' : 'incomplete'}`,
      item: updated
    });
  } catch (error) {
    next(error);
  }
};

const deleteChecklistItem = async (req, res, next) => {
  try {
    const item = await prisma.checklistItem.findUnique({
      where: { id: req.params.itemId },
      include: { checklist: true }
    });

    if (!item) {
      return res.status(404).json({ error: 'Item not found' });
    }

    if (item.checklist.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.checklistItem.delete({
      where: { id: req.params.itemId }
    });

    res.json({ message: 'Item deleted successfully' });
  } catch (error) {
    next(error);
  }
};

const getMemberChecklists = async (req, res, next) => {
  try {
    const memberId = req.params.memberId || req.user.id;

    const member = await prisma.member.findUnique({
      where: { id: memberId }
    });

    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    if (member.teamId !== req.user.teamId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const items = await prisma.checklistItem.findMany({
      where: { memberId },
      include: {
        checklist: {
          select: { id: true, title: true, weekStartDate: true }
        }
      },
      orderBy: { checklist: { weekStartDate: 'desc' } }
    });

    res.json(items);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getChecklists,
  createChecklist,
  getChecklist,
  updateChecklist,
  deleteChecklist,
  addChecklistItem,
  toggleChecklistItem,
  deleteChecklistItem,
  getMemberChecklists
};
