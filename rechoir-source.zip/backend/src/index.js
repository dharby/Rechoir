require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');

const config = require('./config');
const { errorHandler, notFoundHandler } = require('./middleware/errorHandler');

const authRoutes = require('./routes/auth');
const teamRoutes = require('./routes/teams');
const memberRoutes = require('./routes/members');
const prayerChainRoutes = require('./routes/prayerChains');
const paymentRoutes = require('./routes/payments');
const rehearsalRoutes = require('./routes/rehearsals');
const checklistRoutes = require('./routes/checklists');
const uniformRoutes = require('./routes/uniforms');
const songRoutes = require('./routes/songs');
const chatRoutes = require('./routes/chat');
const notificationRoutes = require('./routes/notifications');

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: config.corsOrigin,
    methods: ['GET', 'POST', 'PATCH', 'DELETE'],
    credentials: true
  }
});

app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(cors({
  origin: config.corsOrigin,
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
  req.io = io;
  next();
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use('/api/auth', authRoutes);
app.use('/api/teams', teamRoutes);
app.use('/api/members', memberRoutes);
app.use('/api/prayer-chains', prayerChainRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/rehearsals', rehearsalRoutes);
app.use('/api/checklists', checklistRoutes);
app.use('/api/uniform-events', uniformRoutes);
app.use('/api/songs', songRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/notifications', notificationRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const activeUsers = new Map();

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('join-room', (roomId) => {
    socket.join(`room:${roomId}`);
    console.log(`Socket ${socket.id} joined room:${roomId}`);
  });

  socket.on('leave-room', (roomId) => {
    socket.leave(`room:${roomId}`);
    console.log(`Socket ${socket.id} left room:${roomId}`);
  });

  socket.on('typing', ({ roomId, userName }) => {
    socket.to(`room:${roomId}`).emit('user-typing', { userName });
  });

  socket.on('stop-typing', ({ roomId }) => {
    socket.to(`room:${roomId}`).emit('user-stop-typing');
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
    activeUsers.delete(socket.id);
  });
});

const PORT = config.port;

server.listen(PORT, () => {
  console.log(`RECHOIR Backend running on port ${PORT}`);
  console.log(`Environment: ${config.nodeEnv}`);
});

process.on('unhandledRejection', (err) => {
  console.error('Unhandled Rejection:', err);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});

module.exports = { app, server, io };
